import java.util.ArrayList;


public class grades {
	private long id;
	private String name;
	private String courseType;
	private double credit;
	private String teacher;
	private String college;
	private String studyType;
	private int year;
	private String xueqi;
	private double score;
	
	public grades(long id, String name, String courseType, double credit, String teacher, String college, String studyType,
			int year, String xueqi, double score) {
		super();
		this.id = id;
		this.name = name;
		this.courseType = courseType;
		this.credit = credit;
		this.teacher = teacher;
		this.college = college;
		this.studyType = studyType;
		this.year = year;
		this.xueqi = xueqi;
		this.score = score;
	}
	public String toString(ArrayList<grades> grades) {
		return "grades [id=" + id + ", name=" + name + ", courseType=" + courseType + ", credit=" + credit
				+ ", teacher=" + teacher + ", college=" + college + ", studyType=" + studyType + ", year=" + year
				+ ", xueqi=" + xueqi + ", score=" + score + "]";
	}
	public long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getCourseType() {
		return courseType;
	}
	public double getCredit() {
		return credit;
	}
	public String getTeacher() {
		return teacher;
	}
	public String getCollege() {
		return college;
	}
	public String getStudyType() {
		return studyType;
	}
	public int getYear() {
		return year;
	}
	public String getXueqi() {
		return xueqi;
	}
	public double getScore() {
		return score;
	}

}


