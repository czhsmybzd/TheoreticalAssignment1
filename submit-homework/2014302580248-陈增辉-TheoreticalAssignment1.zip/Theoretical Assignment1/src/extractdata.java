import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class extractdata {
	public static String heads[] = new String[12];
	public static String temp[];
	public static ArrayList<grades> Input(File input) throws IOException{
		Document doc = Jsoup.parse(input,"gb2312");
		
		Element mytable = doc.getElementsByTag("table").first();
		Elements rows = mytable.getElementsByTag("tr");
		
		ArrayList<grades> grades = new ArrayList<grades>();
		
		for(Element ele:rows){
			temp = new String[12];
			
			Elements head = ele.getElementsByTag("th");
			Elements cols = ele.getElementsByTag("td");
			
			int i = 0;
			if(!head.isEmpty()) {
				for(Element el:head)
					heads[i++] = el.text().trim();
				System.out.println(heads);
			}
			
			else {
				for(Element el:cols) 
					temp[i++] = el.text().trim();
				grades a = new grades(Long.parseLong(temp[0]), temp[1], temp[2], 
						Double.parseDouble(temp[3]), temp[4], temp[5], temp[6],
						Integer.parseInt(temp[7]), temp[8], Double.parseDouble(temp[9]));
				grades.add(a);
			}
			

		}
		SortByScore a = new SortByScore();
	    Collections.sort(grades,a);
		return grades;
	}
	
	
}
	
	class SortByScore implements Comparator<grades>{
		public int compare(grades a1,grades a2){
			grades grd1 = (grades)a1;
			grades grd2 = (grades)a2;
			if(grd1.getScore()<grd2.getScore()) return 1;
			else if(grd1.getScore()>grd2.getScore()) return -1;
			return 0;
				
		}

	    public SortByScore(){
	    	super();
	    }
	}

