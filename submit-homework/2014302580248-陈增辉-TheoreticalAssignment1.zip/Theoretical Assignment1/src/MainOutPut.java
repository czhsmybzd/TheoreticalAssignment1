import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class MainOutPut {
	public static void main(String[] args) throws IOException{
		File file = new File("newtest.txt");
		MainOutPut a = new MainOutPut();
		a.processScoreTable(file);
		/*for(int i = 0;!head.isEmpty();i++){
			for(int j = 0;!cols.isEmpty();j++){
				PrintStream ps = new PrintStream(new FileOutputStream("test2.txt"));
				ps.println(temp[j]);// 往文件里写入字符串
			}
		}*/
		
		//String text = doc.table().test();
		
		//PrintStream ps = new PrintStream(new FileOutputStream("test2.txt"));
		//ps.println("http://www.jb51.net");// 往文件里写入字符串
		
		//System.out.println(text);
		
		
	}
	public void processScoreTable(File input){
		try {
		    File file = new File("test2.html");
		    ArrayList<grades> grade = extractdata.Input(file);
		    double averageScore = getAverageScore(grade);
		    double averageGpa = getAverageGpa(grade);
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(input,true));
			for(grades i:grade){
				bufferedWriter.write(i.getId() +"\t"+  i.getName() +"\t"+ i.getCourseType() +"\t"+ 
			            i.getCredit() +"\t"+ i.getTeacher() +"\t"+ i.getCollege() +"\t"+ i.getStudyType() 
						+"\t"+ i.getYear() +"\t"+ i.getXueqi() +"\t"+ i.getScore()+"\r\n");
			}
			bufferedWriter.write("加权平均分是"+averageScore+"综合加权GPA是"+averageGpa);
			bufferedWriter.close();
			System.out.println(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	public static double getAverageScore(ArrayList<grades> a){
		double averageScore;
		double sumCredit = 0;
		double sumScore = 0;
		for(grades i:a){
			double credit = i.getCredit();
			double score = i.getScore();
			sumCredit += credit;
			sumScore += score*credit;
		}
		averageScore = sumScore/sumCredit;
		return averageScore;
	}

	public static double getAverageGpa(ArrayList<grades> a){
		double sumGpa = 0;
		double sumCredit = 0;
		double AverageGpa;
		for(grades i:a){
			double credit = i.getCredit();
			double score = i.getScore();
			double gpa = 0;
			if(score >= 90&&score <= 100) gpa = 4.0;
			else if(score >= 85&&score <= 89) gpa = 3.7;
			else if(score >= 82&&score <= 84) gpa = 3.3;
			else if(score >= 78&&score <= 81) gpa = 3.0;
			else if(score >= 75&&score <= 77) gpa = 2.7;
			else if(score >= 72&&score <= 74) gpa = 2.3;
			else if(score >= 68&&score <= 71) gpa = 2.0;
			else if(score >= 64&&score <= 67) gpa = 1.5;
			else if(score >= 80&&score <= 63) gpa = 1.0;
			else if(score < 60) gpa = 0;
			sumGpa += gpa * credit;
			sumCredit += credit;
		}
		AverageGpa = sumGpa/sumCredit;
		return AverageGpa;
	}

}

